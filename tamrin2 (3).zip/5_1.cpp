#include <iostream>

using namespace std;

class Time{

private:
    int min=0;
    int hour=0;

public:

    Time(int min,int hour){
        changeMinAndHour(hour,min);
    }

    Time(int hour): min(0),hour(hour){}

    void changeMinAndHour(int hour,int min){
        if(min>-1 && min<60){
            this->min=min;
        }else {
            exit(0);
        }
        if(hour>-1 && hour<24)
            this->hour=hour;
        else exit(0);
    }

    int getMin(){
        return min;
    }

    int getHour(){
        return hour;
    }

    int compareTime(Time time){

        if(time.getHour()>hour)
            return -1;

        if(time.getHour()==hour && time.getMin()>min)
            return -1;

        if(time.getHour()==hour && time.getMin()==min)
            return 0;

        return 1;
    }

    string timeState(){
        if(hour>=0 && hour<=11)
            return "Morning";
        if(hour==12 && min==0)
            return "Noon";
        if(hour>=12 && hour<=16)
            return "AfterNoon";
        if(hour>=17 && hour<=19)
            return "Evening";
        return "Night";

    }

};

int main()
{

    Time time1(59,17);
    Time time2(23,6);
    Time time3(0,12);
    Time time4(29,15);
    Time time5(23,23);

    printf("time1 -> %02d:%02d , %s\n",time1.getHour(),time1.getMin(),time1.timeState().c_str());
    printf("time2 -> %02d:%02d , %s\n",time2.getHour(),time2.getMin(),time2.timeState().c_str());
    printf("time3 -> %02d:%02d , %s\n",time3.getHour(),time3.getMin(),time3.timeState().c_str());
    printf("time4 -> %02d:%02d , %s\n",time4.getHour(),time4.getMin(),time4.timeState().c_str());
    printf("time5 -> %02d:%02d , %s\n",time5.getHour(),time5.getMin(),time5.timeState().c_str());

    cout<<"compare 1,2 ->"<<time1.compareTime(time2)<<endl;
    cout<<"compare 3,4 ->"<<time3.compareTime(time4)<<endl;
    cout<<"compare 2,5 ->"<<time2.compareTime(time5)<<endl;

    return 0;
}

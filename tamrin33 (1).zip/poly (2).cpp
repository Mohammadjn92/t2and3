#include <iostream>
#include <string>
#include <math.h>
#include <stdlib.h>
#include <cstdio>
#include <fstream>

using namespace std;

class Term {
    double factor;
    double power;
public:
    Term(double factor, double power) : factor(factor), power(power) {}

    Term() : factor(0), power(0) {}

    bool operator==(const Term &t) const {
        if (this->power != t.power)
            return false;
        if (this->factor != t.factor)
            return false;
        return true;
    }

    bool operator!=(const Term &t) const {
        return !(*this == t);
    }

    bool operator>(const Term &t) const{
        if (this->power < t.power)
            return false;
        if (this->factor <= t.factor && (this->power == t.power))
            return false;
        return true;
    }

    bool operator>=(const Term &t) const{
        if (this->power < t.power)
            return false;
        if (this->factor < t.factor && (this->power == t.power))
            return false;
        return true;
    }

    bool operator<(const Term &t) const{
        if (this->power > t.power)
            return false;
        if (this->factor >= t.factor && (this->power == t.power))
            return false;
        return true;
    }

    bool operator<=(const Term &t) const{
        if (this->power > t.power)
            return false;
        if (this->factor > t.factor && (this->power == t.power))
            return false;
        return true;
    }

    double getFactor() {
        return factor;
    }

    void setFactor(double factor) {
        Term::factor = factor;
    }

    double getPower() {
        return power;
    }

    void setPower(double power) {
        Term::power = power;
    }

    friend ostream &operator<<(ostream &out, const Term &term) {
        if (term.factor != 0) {
            if (term.factor != 1 && term.factor != -1)
                out << term.factor;
            if (term.factor == -1) out << "-";
            if (term.power != 0) {
                out << "x";
                if (term.power != 1)
                    out << "^" << term.power;
            }
            cout << "\n";
        }

        return out;
    }
};

class Polynomial {
    Term *terms{};
    int sizeArr;
    int capacity;
public:
    Polynomial() {
        terms = new Term[10];
        sizeArr = 0;
        capacity = 10;
    }

    ~Polynomial() {
        delete[] terms;
    }

    Term *getTerm() {
        return terms;
    }

    void increaseCapacity(int number) {
        Term *temp = new Term[this->sizeArr];
        for (int i = 0; i < this->sizeArr; ++i) {
            temp[i] = this->terms[i];
        }
        delete[] this->terms;
        int z = this->sizeArr;
        this->capacity += number;
        this->terms = new Term[this->capacity];
        for (int i = 0; i < z; ++i) {
            this->terms[i] = temp[i];
        }
        delete[] temp;
    }

    friend ostream &operator<<(ostream &out, const Polynomial &p) {
        bool printSign = false;
        for (int i = 0; i < p.sizeArr; ++i) {
            if (printSign) {
                if (p.terms[i].getFactor() > 0)
                    cout << " + ";
            }
            if (p.terms[i].getFactor() != 0) {
                printSign = true;
                if (p.terms[i].getFactor() != 1 && p.terms[i].getFactor() != -1)
                    if(p.terms[i].getFactor()<0){
                        if(i==0)
                            out <<"-";
                        else{
                            out <<" - ";}
                        out<< -p.terms[i].getFactor();
                    }
                    else {
                        out << p.terms[i].getFactor();
                    }
                if (p.terms[i].getFactor() == -1 && i==0) out << "-";
                else if (p.terms[i].getFactor() == -1 && i!=0) {
                    out << " - ";
                }
                if ((p.terms[i].getFactor() == -1 || p.terms[i].getFactor() == 1) && p.terms[i].getPower() == 0)
                    out << 1;
                if (p.terms[i].getPower() != 0) {
                    out << "x";
                    if (p.terms[i].getPower() != 1)
                        out << "^" << p.terms[i].getPower();
                }
            }
        }
        if (!printSign)cout << 0;
        cout << "\n";
        return out;
    }

    Polynomial operator+(const Polynomial &p) {
        Polynomial polynomial;
        polynomial.sizeArr = 0;
        if (polynomial.capacity <= p.sizeArr + this->sizeArr)
            polynomial.increaseCapacity(p.sizeArr + this->sizeArr - polynomial.capacity);
        bool rev = false;
        for (int i = 0; i < this->sizeArr; i++) {
            rev = false;
            for (int j = 0; j < p.sizeArr; j++) {
                if (this->getTerm()[i].getPower() == p.terms[j].getPower()) {
                    rev = true;
                    polynomial.terms[polynomial.sizeArr].setPower(p.terms[j].getPower());
                    polynomial.terms[polynomial.sizeArr].setFactor(
                                p.terms[j].getFactor() + this->getTerm()[i].getFactor());
                    polynomial.sizeArr++;

                }
            }
            if (!rev) {
                polynomial.terms[polynomial.sizeArr].setPower(this->getTerm()[i].getPower());
                polynomial.terms[polynomial.sizeArr].setFactor(this->getTerm()[i].getFactor());
                polynomial.sizeArr++;
            }

        }
        for (int i = 0; i < p.sizeArr; i++) {
            rev = false;
            for (int j = 0; j < this->sizeArr; j++) {
                if (this->getTerm()[j].getPower() == p.terms[i].getPower()) {
                    rev = true;
                }
            }
            if (!rev) {
                polynomial.terms[polynomial.sizeArr].setPower(p.terms[i].getPower());
                polynomial.terms[polynomial.sizeArr].setFactor(p.terms[i].getFactor());
                polynomial.sizeArr++;
            }

        }
        sort(polynomial);
        return polynomial;
    }

    static void sort(Polynomial &polynomial) {
        for (int i = 0; i < polynomial.sizeArr - 1; ++i) {
            for (int j = i + 1; j < polynomial.sizeArr; ++j) {
                if (polynomial.terms[i].getPower() == polynomial.terms[j].getPower()) {
                    polynomial.terms[i].setFactor(polynomial.terms[i].getFactor() + polynomial.terms[j].getFactor());
                    polynomial.terms[j].setFactor(0);
                    polynomial.terms[j].setPower(0);
                } else if (polynomial.terms[i].getPower() < polynomial.terms[j].getPower()) {
                    Term term1 = polynomial.terms[i];
                    polynomial.terms[i] = polynomial.terms[j];
                    polynomial.terms[j] = term1;
                }
            }
        }
        Term t;
        for (int var = 0; var < polynomial.sizeArr - 1; ++var) {
            if (polynomial.terms[var].getFactor() == 0) {
                for (int i = var; i < polynomial.sizeArr - 1; ++i) {
                    polynomial.terms[i] = polynomial.terms[i + 1];
                    polynomial.terms[i + 1] = t;
                }
                if (polynomial.sizeArr > 0)polynomial.sizeArr--;
            }
        }
        if(polynomial.terms[polynomial.sizeArr-1].getFactor()==0)
            polynomial.sizeArr--;
    }

    Polynomial operator/(const Polynomial &p) {
        Polynomial temp = *this;
        Polynomial result,resultTemp;
        result.sizeArr = 0;
        resultTemp.sizeArr = 1;
        for (int j = 0; ((temp.terms[0].getPower() >= p.terms[0].getPower() &&temp.terms[0].getPower()!=0 )||
                         (temp.terms[0].getPower()==0 && p.terms[0].getFactor()<temp.terms[0].getFactor() &&
                          temp.terms[0].getPower() >= p.terms[0].getPower())) && temp.terms[0].getFactor()!=0; j++) {
            if(temp.terms[0].getPower()!=0){
                result.terms[j].setPower(temp.terms[0].getPower() - p.terms[0].getPower());
                result.terms[j].setFactor(temp.terms[0].getFactor() / p.terms[0].getFactor());
                resultTemp.terms[0].setPower(temp.terms[0].getPower() - p.terms[0].getPower());
                resultTemp.terms[0].setFactor(temp.terms[0].getFactor() / p.terms[0].getFactor());
            }else {
                result.terms[j].setPower(temp.terms[0].getPower() - p.terms[0].getPower());
                result.terms[j].setFactor(int(temp.terms[0].getFactor()) /int( p.terms[0].getFactor()));
                resultTemp.terms[0].setPower(temp.terms[0].getPower() - p.terms[0].getPower());
                resultTemp.terms[0].setFactor(int(temp.terms[0].getFactor()) /int( p.terms[0].getFactor()));
            }
            result.sizeArr++;
            temp -= resultTemp * p;
        }
        sort(result);
        return result;
    }

    Polynomial operator%(const Polynomial &p) {
        Polynomial temp = *this;
        Polynomial result,resultTemp;
        result.sizeArr = 0;
        resultTemp.sizeArr = 1;
        for (int j = 0; ((temp.terms[0].getPower() >= p.terms[0].getPower() &&temp.terms[0].getPower()!=0 )||
                         (temp.terms[0].getPower()==0 && p.terms[0].getFactor()<temp.terms[0].getFactor() && temp.terms[0].getPower() >= p.terms[0].getPower())) && temp.terms[0].getFactor()!=0; j++) {
            if(temp.terms[0].getPower()!=0){
                result.terms[j].setPower(temp.terms[0].getPower() - p.terms[0].getPower());
                result.terms[j].setFactor(temp.terms[0].getFactor() / p.terms[0].getFactor());
                resultTemp.terms[0].setPower(temp.terms[0].getPower() - p.terms[0].getPower());
                resultTemp.terms[0].setFactor(temp.terms[0].getFactor() / p.terms[0].getFactor());
            }else {
                result.terms[j].setPower(temp.terms[0].getPower() - p.terms[0].getPower());
                result.terms[j].setFactor(int(temp.terms[0].getFactor()) /int( p.terms[0].getFactor()));
                resultTemp.terms[0].setPower(temp.terms[0].getPower() - p.terms[0].getPower());
                resultTemp.terms[0].setFactor(int(temp.terms[0].getFactor()) /int( p.terms[0].getFactor()));
            }
            result.sizeArr++;
            temp -= resultTemp * p;
        }
        sort(temp);
        return temp;
    }

    void operator%=(const Polynomial &p) {
        *this = *this % p;
    }

    void operator/=(const Polynomial &p) {
        *this = *this / p;
    }

    Polynomial operator*(const Polynomial &p) {
        Polynomial polynomial;
        polynomial.sizeArr = 0;
        if (polynomial.capacity < p.sizeArr * this->sizeArr)
            polynomial.increaseCapacity(p.sizeArr * this->sizeArr - polynomial.capacity);
        int k = 0;
        for (int i = 0; i < this->sizeArr; i++) {
            for (int j = 0; j < p.sizeArr; j++, k++) {
                polynomial.terms[polynomial.sizeArr].setPower(p.terms[j].getPower() + this->terms[i].getPower());
                polynomial.terms[polynomial.sizeArr].setFactor(
                            p.terms[j].getFactor() * this->getTerm()[i].getFactor());
                polynomial.sizeArr++;
            }

        }
        sort(polynomial);
        return polynomial;
    }

    void operator*=( Polynomial &p) {
        *this = *this * p;
    }

    bool operator==(const Polynomial &p) {
        if (this->sizeArr != p.sizeArr)
            return false;
        for (int i = 0; i < sizeArr; ++i) {
            if (p.terms[i] != this->terms[i])
                return false;
        }
        return true;
    }

    bool operator>(const Polynomial &p){
        sort(*this);
        for (int i = 0; i < max(sizeArr,p.sizeArr); ++i) {
            if (p.terms[i] < this->terms[i])
                return true;
            else if(p.terms[i] > this->terms[i])
                return false;
        }
        return false;
    }

    bool operator>=(const Polynomial &p){
        sort(*this);
        for (int i = 0; i < max(sizeArr,p.sizeArr); ++i) {
            if (p.terms[i] < this->terms[i])
                return true;
            else if(p.terms[i] > this->terms[i])
                return false;
        }
        return true;
    }

    bool operator<(const Polynomial &p){
        sort(*this);
        for (int i = 0; i < max(sizeArr,p.sizeArr); ++i) {
            if (p.terms[i] > this->terms[i])
                return true;
            else if(p.terms[i] < this->terms[i])
                return false;
        }
        return false;
    }

    bool operator<=(const Polynomial &p){
        for (int i = 0; i < max(sizeArr,p.sizeArr); ++i) {
            if (p.terms[i] > this->terms[i])
                return true;
            else if(p.terms[i] < this->terms[i])
                return false;
        }
        return true;
    }



    bool operator!=(const Polynomial &p) {
        return !(*this == p);
    }

    Polynomial operator-(const Polynomial &p) {
        Polynomial polynomial;
        polynomial.sizeArr = 0;
        bool rev = false;
        if (polynomial.capacity < p.sizeArr + this->sizeArr)
            polynomial.increaseCapacity(p.sizeArr + this->sizeArr - polynomial.capacity);
        for (int i = 0; i < this->sizeArr; i++) {
            rev = false;
            for (int j = 0; j < p.sizeArr; j++) {
                if (this->getTerm()[i].getPower() == p.terms[j].getPower()) {
                    rev = true;
                    polynomial.terms[polynomial.sizeArr].setPower(p.terms[j].getPower());
                    polynomial.terms[polynomial.sizeArr].setFactor(
                                this->getTerm()[i].getFactor() - p.terms[j].getFactor());
                    polynomial.sizeArr++;

                }
            }
            if (!rev) {
                polynomial.terms[polynomial.sizeArr].setPower(this->getTerm()[i].getPower());
                polynomial.terms[polynomial.sizeArr].setFactor(this->getTerm()[i].getFactor());
                polynomial.sizeArr++;
            }

        }
        for (int i = 0; i < p.sizeArr; i++) {
            rev = false;
            for (int j = 0; j < this->sizeArr; j++) {
                if (this->getTerm()[j].getPower() == p.terms[i].getPower()) {
                    rev = true;
                }
            }
            if (!rev) {
                polynomial.terms[polynomial.sizeArr].setPower(p.terms[i].getPower());
                polynomial.terms[polynomial.sizeArr].setFactor(-(p.terms[i].getFactor()));
                polynomial.sizeArr++;
            }

        }
        sort(polynomial);
        return polynomial;
    }

    void operator+=(const Polynomial &p) {
        bool rev = false;
        if (this->capacity < p.sizeArr + this->sizeArr)
            this->increaseCapacity(p.sizeArr + this->sizeArr - this->capacity);
        for (int i = 0; i < p.sizeArr; i++) {
            rev = false;
            for (int j = 0; j < this->sizeArr; j++) {
                if (this->getTerm()[j].getPower() == p.terms[i].getPower()) {
                    rev = true;
                    this->terms[j].setFactor(
                                p.terms[i].getFactor() + this->getTerm()[j].getFactor());

                }
            }
            if (!rev) {
                this->terms[this->sizeArr].setPower(p.terms[i].getPower());
                this->terms[this->sizeArr].setFactor(p.terms[i].getFactor());
                this->sizeArr++;
            }

        }
        sort(*this);
    }

    void operator-=(const Polynomial &p) {
        bool rev = false;
        if (this->capacity < p.sizeArr + this->sizeArr)
            this->increaseCapacity(p.sizeArr + this->sizeArr - this->capacity);
        for (int i = 0; i < p.sizeArr; i++) {
            rev = false;
            for (int j = 0; j < this->sizeArr; j++) {
                if (this->getTerm()[j].getPower() == p.terms[i].getPower()) {
                    rev = true;
                    this->terms[j].setFactor(
                                this->getTerm()[j].getFactor() - p.terms[i].getFactor());

                }
            }
            if (!rev) {
                this->terms[this->sizeArr].setPower(p.terms[i].getPower());
                this->terms[this->sizeArr].setFactor(-(p.terms[i].getFactor()));
                this->sizeArr++;
            }

        }
        sort(*this);
    }

    Polynomial &operator=(const Polynomial &p) {
        if (*this != p) {
            terms = new Term[p.capacity];
            for (int j = 0; j < p.sizeArr; j++) {
                this->terms[j].setPower(p.terms[j].getPower());
                this->terms[j].setFactor(p.terms[j].getFactor());
            }
            this->sizeArr = p.sizeArr;
            this->capacity = p.capacity;
        }
        return *this;
    }

    Polynomial(const Polynomial &p) {
        terms = new Term[p.capacity];
        for (int j = 0; j < p.sizeArr; j++) {
            this->terms[j].setPower(p.terms[j].getPower());
            this->terms[j].setFactor(p.terms[j].getFactor());
        }
        this->sizeArr = p.sizeArr;
        this->capacity = p.capacity;
    }

    double operator()(double x) const {
        double final = 0;
        for (int j = 0; j < this->sizeArr; j++) {
            double f = 0;
            if (this->terms[j].getFactor() != 0) {
                f = (this->terms[j].getFactor()) * (pow(x, this->terms[j].getPower()));
            }
            final += f;
        }
        return final;
    }

    Term operator[](int x) const {
        if (x >= 0 && x < this->sizeArr) {
            return this->terms[x];
        }
        cout << "out of range" << endl;
        return {};
    }
    Polynomial &operator~(){
        sort(*this);
        for(int i=0;i<sizeArr;i++){
            terms[i].setFactor(terms[i].getPower()*terms[i].getFactor());
            terms[i].setPower(terms[i].getPower()-1);
        }
        sort(*this);
        return *this;
    }
    int getDegree(){
        sort(*this);
        return this->getTerm()[0].getPower();
    }

    friend istream &operator>>(istream &in, Polynomial &c) {

        string temp;
        c.sizeArr = 0;
        getline(in, temp);
        string result;
        for (char i : temp) {
            if (i != ' ') {
                result += i;
            }
        }
        result += " ";
        for (int j = 0; result[j]; ++j) {
            if (check(result[j]) || result[j] == 'x') {
                bool negative = isNegative(result, j);
                string factor;
                bool zarib1 = true;
                if (negative)factor += "-";
                for (int i = j; (result[i] != ' ' || result[i] || result[i] != '-' ||
                                 result[i] != '+' || result[i] != 'x') &&
                     (check(result[i]) || result[i] == '.'); ++i, j++) {
                    factor += result[i];
                    zarib1 = false;
                }
                if (isX(result, j)) {
                    if (!zarib1)
                        c.terms[c.sizeArr].setFactor(stod(factor));
                    else {
                        if (negative)
                            c.terms[c.sizeArr].setFactor(-1);
                        else c.terms[c.sizeArr].setFactor(1);
                    }
                    if (result[j + 1] == '^') {
                        j += 2;
                        string power;
                        for (int i = j; check(result[i]); ++i, j++) {
                            power += result[i];
                        }
                        c.terms[c.sizeArr].setPower(stod(power));
                    } else {
                        c.terms[c.sizeArr].setPower(1);
                    }
                } else {
                    c.terms[c.sizeArr].setFactor(stod(factor));
                    c.terms[c.sizeArr].setPower(0);
                }
            }
            if ((result[j] == '-' || result[j] == '+' || result[j] == ' ') && j != 0)c.sizeArr++;
            if (c.sizeArr == c.capacity)
                c.increaseCapacity(100);
        }
        sort(c);
        return in;
    }

    int getSizeArr() const;

private:
    static bool check(char c) {
        string s;
        s += c;
        try {
            int number = stoi(s);
            return true;
        }
        catch (const exception &e) {
            return false;
        }
    }

    static bool isNegative(string s, int j) {
        try {
            if (s[j - 1] == '-')
                return true;
            return false;
        } catch (const exception &e) {
            return false;
        }
    }

    static bool isX(string s, int j) {

        try {
            if (s[j] == 'x')
                return true;
            return false;
        } catch (const exception &e) {
            return false;
        }
    }

};

void printMenu();
void printMainMenu();

void savePolyToText(Polynomial& p){
    string fileName;
    cout<<"Enter file name : ";
    cin>>fileName;
    ofstream MyFile(("D:\\session1-1\\tamrin"+fileName+".txt").c_str());
    bool printSign = false;
    for (int i = 0; i < p.getSizeArr(); ++i) {
        if (printSign) {
            if (p.getTerm()[i].getFactor() > 0)
                MyFile << " + ";
        }
        if (p.getTerm()[i].getFactor() != 0) {
            printSign = true;
            if (p.getTerm()[i].getFactor() != 1 && p.getTerm()[i].getFactor() != -1)
                if(p.getTerm()[i].getFactor()<0){
                    if(i==0)
                        MyFile <<"-";
                    else{
                        MyFile <<" - ";}
                    MyFile<< -p.getTerm()[i].getFactor();
                }
                else {
                    MyFile << p.getTerm()[i].getFactor();
                }
            if (p.getTerm()[i].getFactor() == -1 && i==0) MyFile << "-";
            else if (p.getTerm()[i].getFactor() == -1 && i!=0) {
                MyFile << " - ";
            }
            if ((p.getTerm()[i].getFactor() == -1 || p.getTerm()[i].getFactor() == 1) && p.getTerm()[i].getPower() == 0)
                MyFile << 1;
            if (p.getTerm()[i].getPower() != 0) {
                MyFile << "x";
                if (p.getTerm()[i].getPower() != 1)
                    MyFile << "^" << p.getTerm()[i].getPower();
            }
        }
    }
    if (!printSign)cout << 0;
}

bool loadPolyFromText(Polynomial& p){
    string fileName;
    cout<<"Enter file name : ";
    cin>>fileName;
    try {
        fstream MyFile(("D:\\session1-1\\tamrin"+fileName+".txt").c_str());
        if(!MyFile)return false;
        MyFile>>p;
    } catch (const exception &e) {
        cout<<"File not founded!!\n";
        return false;
    }
    return true;
}

void savePolyToBin(Polynomial& p){
    string fileName;
    cout<<"Enter file name : ";
    cin>>fileName;
    ofstream wf(("D:\\session1-1\\tamrin"+fileName+".bin").c_str(), ios::out | ios::binary);
    if(!wf) {
        cout << "Cannot open file!" << endl;
        return;
    }

    wf.write((char *) &p, sizeof(Polynomial));
    wf.close();
}

bool loadPolyFromBin(Polynomial& p){
    string fileName;
    cout<<"Enter file name : ";
    cin>>fileName;
    ifstream rf(("D:\\session1-1\\tamrin"+fileName+".bin").c_str(), ios::out | ios::binary);

    if(!rf) {
        cout << "Cannot open file!" << endl;
        return false;
    }
    rf.read((char *) &p, sizeof(Polynomial));
    return true;

}

int main() {
    int x, index;
    double value;
    Polynomial p1, p2;
    bool show = true;
    while (show) {
        //        system("cls");
        printMainMenu();
        cin >> x;
        if(x==1){
            cout<<"Current Polynomial = "<<p1;
            bool show2=true;
            while (show2) {
                printMenu();
                cin>>x;
                switch (x) {
                case 1:
                    cin.ignore();
                    //                cout << "polynomial 1 : ";
                    //                cin >> p1;
                    cout << "polynomial 2 : ";
                    cin >> p2;
                    cout << "result : " << p1 + p2;
                    p1+=p2;
                    break;
                case 2:
                    cin.ignore();
                    //                cout << "polynomial 1 : ";
                    //                cin >> p1;
                    cout << "polynomial 2 : ";
                    cin >> p2;
                    cout << "result : " << p1 - p2;
                    p1-=p2;
                    break;
                case 6:
                    cin.ignore();
                    //                cout << "polynomial 1 : ";
                    //                cin >> p1;
                    cout << "value : ";
                    cin >> value;
                    cout << p1(value) << endl;
                    break;
                
                case 3:
                    cin.ignore();
                    //                cout << "polynomial 1 : ";
                    //                cin >> p1;
                    cout << "polynomial 2 : ";
                    cin >> p2;
                    cout << "result : " << p1 * p2;
                    p1*=p2;
                    break;
                
                case 4:
                    cin.ignore();
                    //                cout << "polynomial 1 : ";
                    //                cin >> p1;
                    cout << "result : " << ~p1;
                    break;
                case 5:
                    cin.ignore();
                    //                cout << "polynomial 1 : ";
                    //                cin >> p1;
                    cout << "result : " << p1.getDegree()<<endl;
                    break;
                case 7:
                    cin.ignore();
                    //                cout << "polynomial 1 : ";
                    //                cin >> p1;
                    cout << "polynomial 2 : ";
                    cin >> p2;
                    cout<<"Comparing Current_Polynomial with Other_Polynomial\n\n";
                    cout<<"Current_Polynomial > Other_Polynomial: ";
                    if(p1 > p2)cout<<"True";else cout<<"False";
                    cout<<endl;
                    cout<<"Current_Polynomial >= Other_Polynomial: ";
                    if(p1>=p2)cout<<"True";else cout<<"False";
                    cout<<endl;
                    cout<<"Current_Polynomial < Other_Polynomial: ";
                    if(p1<p2)cout<<"True";else cout<<"False";
                    cout<<endl;
                    cout<<"Current_Polynomial <= Other_Polynomial: ";
                    if(p1<=p2)cout<<"True";else cout<<"False";
                    cout<<endl;
                    cout<<"Current_Polynomial == Other_Polynomial: ";
                    if(p1==p2)cout<<"True";else cout<<"False";
                    cout<<endl;
                    break;
                case 8:
                    savePolyToText(p1);
                    break;
                case 9:
                                    savePolyToBin(p1);
                    break;
                case 10:
                    show2 = false;
                    break;
                default:
                    break;
                }

            }
        }
        else if(x==2){
            Polynomial::sort(p1);
            bool load= loadPolyFromText(p1);
            if(!load){ cout<<"not found with file name!!"<<endl;
                continue;}
            cout<<"Current Polynomial = "<<p1;

            bool show2=true;
            while (show2) {
                printMenu();
                cin>>x;
                switch (x) {
                case 1:
                    cin.ignore();
                    //                cout << "polynomial 1 : ";
                    //                cin >> p1;
                    cout << "polynomial 2 : ";
                    cin >> p2;
                    cout << "result : " << p1 + p2;
                    p1+=p2;
                    break;
                case 2:
                    cin.ignore();
                    //                cout << "polynomial 1 : ";
                    //                cin >> p1;
                    cout << "polynomial 2 : ";
                    cin >> p2;
                    cout << "result : " << p1 - p2;
                    p1-=p2;
                    break;
                case 6:
                    cin.ignore();
                    //                cout << "polynomial 1 : ";
                    //                cin >> p1;
                    cout << "value : ";
                    cin >> value;
                    cout << p1(value) << endl;
                    break;
                
                case 3:
                    cin.ignore();
                    //                cout << "polynomial 1 : ";
                    //                cin >> p1;
                    cout << "polynomial 2 : ";
                    cin >> p2;
                    cout << "result : " << p1 * p2;
                    p1*=p2;
                    break;
                
                case 4:
                    cin.ignore();
                    //                cout << "polynomial 1 : ";
                    //                cin >> p1;
                    cout << "result : " << ~p1;
                    break;
                case 5:
                    cin.ignore();
                    //                cout << "polynomial 1 : ";
                    //                cin >> p1;
                    cout << "result : " << p1.getDegree()<<endl;
                    break;
                case 7:
                    cin.ignore();
                    //                cout << "polynomial 1 : ";
                    //                cin >> p1;
                    cout << "polynomial 2 : ";
                    cin >> p2;
                    cout<<"Comparing Current_Polynomial with Other_Polynomial\n\n";
                    cout<<"Current_Polynomial > Other_Polynomial: ";
                    if(p1 > p2)cout<<"True";else cout<<"False";
                    cout<<endl;
                    cout<<"Current_Polynomial >= Other_Polynomial: ";
                    if(p1>=p2)cout<<"True";else cout<<"False";
                    cout<<endl;
                    cout<<"Current_Polynomial < Other_Polynomial: ";
                    if(p1<p2)cout<<"True";else cout<<"False";
                    cout<<endl;
                    cout<<"Current_Polynomial <= Other_Polynomial: ";
                    if(p1<=p2)cout<<"True";else cout<<"False";
                    cout<<endl;
                    cout<<"Current_Polynomial == Other_Polynomial: ";
                    if(p1==p2)cout<<"True";else cout<<"False";
                    cout<<endl;
                    break;
                case 8:
                    savePolyToText(p1);
                    break;
                case 9:
                    savePolyToBin(p1);
                    break;
                case 10:
                    show2 = false;
                    break;
                default:
                    break;
                }

            }
        }
        else if(x==3){
            Polynomial::sort(p1);
           bool load= loadPolyFromBin(p1);
           if(!load){ cout<<"not found with file name!!"<<endl;
               continue;}
           cout<<"Current Polynomial = "<<p1;

           bool show2=true;
           while (show2) {
               printMenu();
               cin>>x;
               switch (x) {
               case 1:
                   cin.ignore();
                   //                cout << "polynomial 1 : ";
                   //                cin >> p1;
                   cout << "polynomial 2 : ";
                   cin >> p2;
                   cout << "result : " << p1 + p2;
                   p1+=p2;
                   break;
               case 2:
                   cin.ignore();
                   //                cout << "polynomial 1 : ";
                   //                cin >> p1;
                   cout << "polynomial 2 : ";
                   cin >> p2;
                   cout << "result : " << p1 - p2;
                   p1-=p2;
                   break;
               case 6:
                   cin.ignore();
                   //                cout << "polynomial 1 : ";
                   //                cin >> p1;
                   cout << "value : ";
                   cin >> value;
                   cout << p1(value) << endl;
                   break;
               
               case 3:
                   cin.ignore();
                   //                cout << "polynomial 1 : ";
                   //                cin >> p1;
                   cout << "polynomial 2 : ";
                   cin >> p2;
                   cout << "result : " << p1 * p2;
                   p1*=p2;
                   break;
               
               case 4:
                   cin.ignore();
                   //                cout << "polynomial 1 : ";
                   //                cin >> p1;
                   cout << "result : " << ~p1;
                   break;
               case 5:
                   cin.ignore();
                   //                cout << "polynomial 1 : ";
                   //                cin >> p1;
                   cout << "result : " << p1.getDegree()<<endl;
                   break;
               case 7:
                   cin.ignore();
                   //                cout << "polynomial 1 : ";
                   //                cin >> p1;
                   cout << "polynomial 2 : ";
                   cin >> p2;
                   cout<<"Comparing Current_Polynomial with Other_Polynomial\n\n";
                   cout<<"Current_Polynomial > Other_Polynomial: ";
                   if(p1 > p2)cout<<"True";else cout<<"False";
                   cout<<endl;
                   cout<<"Current_Polynomial >= Other_Polynomial: ";
                   if(p1>=p2)cout<<"True";else cout<<"False";
                   cout<<endl;
                   cout<<"Current_Polynomial < Other_Polynomial: ";
                   if(p1<p2)cout<<"True";else cout<<"False";
                   cout<<endl;
                   cout<<"Current_Polynomial <= Other_Polynomial: ";
                   if(p1<=p2)cout<<"True";else cout<<"False";
                   cout<<endl;
                   cout<<"Current_Polynomial == Other_Polynomial: ";
                   if(p1==p2)cout<<"True";else cout<<"False";
                   cout<<endl;
                   break;
               case 8:
                   savePolyToText(p1);
                   break;
               case 9:
                   savePolyToBin(p1);
                   break;
               case 10:
                   show2 = false;
                   break;
               default:
                   break;
               }

           }

        }
        else if (x==4) {
            return 0;
        }
        else {
            continue;
        }
    }
}

void printMenu() {
    cout << "1- add polynomials\n"
            "2- subtract polynomials\n"
            "3- multiply\n"
            "4- Derivative\n"
            "5- Find Degree\n"
            "6- Find Value for specific 𝑥\n"
            "7- compare\n"
            "8- Save to a text file\n"
            "9- Save to a binary file\n"
            "10- back\n";

}

void printMainMenu(){
    cout<<"1.New Polynomial\n"
          "2.Load from text file\n"
          "3.Load from binary file\n"
          "4.Quit\n";
}

int Polynomial::getSizeArr() const
{
    return sizeArr;
}
